# plotter.R

mydata = read.csv("summaryzookeeper.csv")

mydatanozk = read.csv("summarynozk.csv")

nozk <- unlist(apply(mydatanozk, 1, function(x) rep(x[1], x[2])))

zookeeperdata <- unlist(apply(mydata, 1, function(x) rep(x[1], x[2])))


responsetime = zookeeperdata#$responsetime

par(xlog=FALSE)
Fn = ecdf(responsetime)

summary(nozk)
sd(nozk)
summary(zookeeperdata)
sd(zookeeperdata)

#plot(Fn, main="Response times", xlab="response time (ms)", ylab="cumulative response proportion", xlim=c(1,500), log="x")
plot(Fn, main="Response times", xlab="response time (ms)", ylab="cumulative response proportion", xlim=c(1,500), log="x")

library(Hmisc)
#g <- c( rep('Response Time (ms)',length(responsetime)) )
x <- c(nozk, zookeeperdata)
g <- c(rep('No ZooKeeper',length(nozk)),rep('ZooKeeper',length(zookeeperdata)))

Ecdf(x, group=g, 
	main="Response time distribution", 
	xlab='Response Time (ms) ',
	ylab = "percentile of requests",
	datadensity="none", 
	col=c('green', 'red'),
	label.curves=list(keys=1:2),
	#log="x",
	q=c(.50,.90,.999),
	xlim=range(0,5)
	)

# second drawing
# Ecdf(originalnozk, group=g, 
# 	main="Response time distribution", 
# 	xlab='Response Time ms ',
	# ylab = "percentile of requests",
	# datadensity="none", 
	# add=TRUE,
	# label.curves=TRUE,
	# col='blue',
	# #log="x",
	# q=c(.50,.90,.999),
	# xlim=range(0,5)
	# )
